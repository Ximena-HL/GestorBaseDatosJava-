package com.example.login

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*

class HomeActivity : AppCompatActivity() {

    private val phpQueryUrl = "http://tuip/php_execute_query.php"  // Cambia aquí

    private lateinit var user: String
    private lateinit var pass: String
    private lateinit var db: String
    private lateinit var table: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        user = intent.getStringExtra("USER").orEmpty()
        pass = intent.getStringExtra("PASS").orEmpty()
        db = intent.getStringExtra("DB").orEmpty()
        table = intent.getStringExtra("TABLE").orEmpty()

        val tvInfo = findViewById<TextView>(R.id.tvInfo)
        val etQuery = findViewById<EditText>(R.id.etQuery)
        val btnExecute = findViewById<Button>(R.id.btnExecute)
        val gridResults = findViewById<GridView>(R.id.gridResults)

        tvInfo.text = "Conectado a: $db como $user\nTabla: $table"
        if (table.isNotEmpty()) {
            etQuery.setText("SELECT * FROM $table LIMIT 50")
        }

        btnExecute.setOnClickListener {
            val query = etQuery.text.toString().trim()
            if (query.isNotEmpty()) {
                CoroutineScope(Dispatchers.IO).launch {
                    val results = postExecuteQuery(user, pass, db, query)
                    withContext(Dispatchers.Main) {
                        if (results != null && results.length() > 0) {
                            val dataList = mutableListOf<String>()
                            val firstRow = results.getJSONObject(0)
                            val columnCount = firstRow.length()
                            gridResults.numColumns = columnCount

                            for (i in 0 until results.length()) {
                                val row = results.getJSONObject(i)
                                row.keys().forEach { key ->
                                    dataList.add(row.getString(key))
                                }
                            }
                            val adapter = ArrayAdapter(this@HomeActivity, android.R.layout.simple_list_item_1, dataList)
                            gridResults.adapter = adapter
                        } else {
                            Toast.makeText(this@HomeActivity, "No hay resultados o error", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } else {
                Toast.makeText(this@HomeActivity, "Escribe una consulta SQL", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun postExecuteQuery(user: String, pass: String, db: String, query: String): org.json.JSONArray? {
        try {
            val url = java.net.URL(phpQueryUrl)
            val postData = "user=$user&pass=$pass&db=$db&query=" + java.net.URLEncoder.encode(query, "UTF-8")

            with(url.openConnection() as java.net.HttpURLConnection) {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

                outputStream.bufferedWriter().use { it.write(postData) }

                if (responseCode == java.net.HttpURLConnection.HTTP_OK) {
                    val responseText = inputStream.bufferedReader().readText()
                    val jsonResponse = org.json.JSONObject(responseText)
                    if (jsonResponse.has("results")) {
                        return jsonResponse.getJSONArray("results")
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }
}
