package com.example.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*

class TablesActivity : AppCompatActivity() {

    private val phpTablesUrl = "http://192.168.1.166/get_tables.php" // Cambia aquí

    private lateinit var listViewTables: ListView
    private lateinit var progressBar: ProgressBar

    private lateinit var user: String
    private lateinit var pass: String
    private lateinit var db: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tables)

        listViewTables = findViewById(R.id.listViewTables)
        progressBar = findViewById(R.id.progressBar)

        user = intent.getStringExtra("USER").orEmpty()
        pass = intent.getStringExtra("PASS").orEmpty()
        db = intent.getStringExtra("DB").orEmpty()

        loadTables()
    }

    private fun loadTables() {
        progressBar.visibility = View.VISIBLE

        CoroutineScope(Dispatchers.IO).launch {
            val tables = postGetTables(user, pass, db)
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                if (tables != null && tables.length() > 0) {
                    val tableList = mutableListOf<String>()
                    for (i in 0 until tables.length()) {
                        tableList.add(tables.getString(i))
                    }

                    val adapter = ArrayAdapter(this@TablesActivity, android.R.layout.simple_list_item_1, tableList)
                    listViewTables.adapter = adapter

                    listViewTables.setOnItemClickListener { _, _, position, _ ->
                        val selectedTable = tableList[position]
                        val intent = Intent(this@TablesActivity, HomeActivity::class.java).apply {
                            putExtra("USER", user)
                            putExtra("PASS", pass)
                            putExtra("DB", db)
                            putExtra("TABLE", selectedTable)
                        }
                        startActivity(intent)
                    }
                } else {
                    Toast.makeText(this@TablesActivity, "No se encontraron tablas o error", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun postGetTables(user: String, pass: String, db: String): org.json.JSONArray? {
        try {
            val url = java.net.URL(phpTablesUrl)
            val postData = "user=$user&pass=$pass&db=$db"

            with(url.openConnection() as java.net.HttpURLConnection) {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

                outputStream.bufferedWriter().use { it.write(postData) }

                if (responseCode == java.net.HttpURLConnection.HTTP_OK) {
                    val responseText = inputStream.bufferedReader().readText()
                    val jsonResponse = org.json.JSONObject(responseText)
                    if (jsonResponse.has("tables")) {
                        return jsonResponse.getJSONArray("tables")
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }
}
