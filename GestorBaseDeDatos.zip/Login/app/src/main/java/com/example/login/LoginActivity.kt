package com.example.login

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*

class LoginActivity : AppCompatActivity() {

    private val phpLoginUrl = "http://tuip/php_login.php"  // Cambia aquí

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val etDatabase = findViewById<EditText>(R.id.etDatabase)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val user = etUsername.text.toString().trim()
            val pass = etPassword.text.toString().trim()
            val db = etDatabase.text.toString().trim()

            if (user.isEmpty() || db.isEmpty()) {
                Toast.makeText(this, "Usuario y Base de datos son obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            CoroutineScope(Dispatchers.IO).launch {
                val response = postLogin(user, pass, db)
                withContext(Dispatchers.Main) {
                    if (response != null && response.has("status") && response.getString("status") == "ok") {
                        val intent = Intent(this@LoginActivity, TablesActivity::class.java).apply {
                            putExtra("USER", user)
                            putExtra("PASS", pass)
                            putExtra("DB", db)
                        }
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this@LoginActivity, "Error en login o conexión", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun postLogin(user: String, pass: String, db: String): org.json.JSONObject? {
        try {
            val url = java.net.URL(phpLoginUrl)
            val postData = "user=$user&pass=$pass&db=$db"

            with(url.openConnection() as java.net.HttpURLConnection) {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

                outputStream.bufferedWriter().use { it.write(postData) }

                if (responseCode == java.net.HttpURLConnection.HTTP_OK) {
                    val responseText = inputStream.bufferedReader().readText()
                    return org.json.JSONObject(responseText)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }
}
